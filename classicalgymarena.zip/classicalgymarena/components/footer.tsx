'use client'

import { Facebook, Instagram, Twitter, MapPin, Phone, Mail } from 'lucide-react'

export function Footer() {
  return (
    <footer className="w-full bg-gradient-to-b from-gray-900 to-black text-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 sm:gap-10 mb-8 sm:mb-12">
          {/* Brand */}
          <div className="space-y-4 text-center sm:text-left">
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white mb-1">Classical Gym Arena</h3>
              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed">
                We care about Health, your well-being is our concern.
              </p>
            </div>
          </div>

          {/* Quick Links */}
          <div className="text-center sm:text-left">
            <h4 className="text-white font-semibold mb-4 sm:mb-6 text-base sm:text-lg">Quick Links</h4>
            <ul className="space-y-2 sm:space-y-3 text-xs sm:text-sm text-gray-400">
              <li><a href="#home" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>Home</a></li>
              <li><a href="#about" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>About</a></li>
              <li><a href="#membership" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>Membership</a></li>
              <li><a href="#classes" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>Classes</a></li>
            </ul>
          </div>

          {/* Services */}
          <div className="text-center sm:text-left">
            <h4 className="text-white font-semibold mb-4 sm:mb-6 text-base sm:text-lg">Services</h4>
            <ul className="space-y-2 sm:space-y-3 text-xs sm:text-sm text-gray-400">
              <li><a href="#" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>Personal Training</a></li>
              <li><a href="#" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>Group Classes</a></li>
              <li><a href="#" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>Wellness Programs</a></li>
              <li><a href="#" className="hover:text-primary transition-colors duration-200 flex items-center justify-center sm:justify-start gap-2"><span className="w-1 h-1 bg-primary rounded-full"></span>Nutrition Coaching</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="text-center sm:text-left">
            <h4 className="text-white font-semibold mb-4 sm:mb-6 text-base sm:text-lg">Contact</h4>
            <div className="space-y-3 sm:space-y-4 text-xs sm:text-sm text-gray-400">
              <a href="#" className="flex items-start gap-3 hover:text-primary transition-colors justify-center sm:justify-start group">
                <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>NO C16, Government House Road, Dutse, Jigawa</span>
              </a>
              <a href="tel:+2348066880296" className="flex items-center gap-3 hover:text-primary transition-colors justify-center sm:justify-start">
                <Phone className="w-4 h-4 flex-shrink-0" />
                <span>+234-8066880296</span>
              </a>
              <a href="mailto:classicalgymarena@gmail.com" className="flex items-center gap-3 hover:text-primary transition-colors justify-center sm:justify-start">
                <Mail className="w-4 h-4 flex-shrink-0" />
                <span className="hidden sm:inline">classicalgymarena@gmail.com</span>
                <span className="sm:hidden">Email us</span>
              </a>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col sm:flex-row justify-center sm:justify-between items-center gap-4 sm:gap-6 mb-8 text-xs sm:text-sm text-gray-400">
            <p>&copy; 2025 Classical Gym Arena. All rights reserved.</p>
            <div className="flex gap-4 sm:gap-6">
              <a href="#" className="hover:text-primary transition-colors duration-200">Privacy Policy</a>
              <a href="#" className="hover:text-primary transition-colors duration-200">Terms of Service</a>
            </div>
          </div>

          {/* Social Icons */}
          <div className="flex justify-center gap-3 sm:gap-4 pt-8 border-t border-gray-800">
            <a href="https://web.facebook.com/profile.php?id=61550901457051" className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-primary/20 hover:bg-primary hover:text-gray-900 flex items-center justify-center transition-all duration-300 group">
              <Facebook className="w-4 h-4 sm:w-5 sm:h-5 text-primary group-hover:text-white" />
            </a>
            <a href="#" className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-primary/20 hover:bg-primary hover:text-gray-900 flex items-center justify-center transition-all duration-300 group">
              <Twitter className="w-4 h-4 sm:w-5 sm:h-5 text-primary group-hover:text-white" />
            </a>
            <a href="#" className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-primary/20 hover:bg-primary hover:text-gray-900 flex items-center justify-center transition-all duration-300 group">
              <Instagram className="w-4 h-4 sm:w-5 sm:h-5 text-primary group-hover:text-white" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
