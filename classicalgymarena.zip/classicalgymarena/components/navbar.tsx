'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'
import Image from 'next/image'

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false)

  const navLinks = [
    { label: 'Home', href: '/#home' },
    { label: 'About', href: '/#about' },
    { label: 'Membership Plans', href: '/#membership' },
    { label: 'Classes', href: '/#classes' },
    { label: 'Trainers', href: '/#trainers' },
    { label: 'Gallery', href: '/gallery' },
    { label: 'Contact', href: '/#contact' },
  ]

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/70 backdrop-blur-md border-b border-gray-100/30 shadow-sm">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0 flex items-center gap-3">
            {/* Logo image */}
            <Image
              src="/images/design-mode/GYMLOGO.jpg"
              alt="Classical Gym Arena Logo"
              width={44}
              height={44}
              className="w-10 h-10 sm:w-11 sm:h-11 object-contain"
            />
            <div className="flex flex-col">
              <h1 className="text-lg sm:text-xl font-bold text-primary">Classical Gym Arena</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">We care about Health</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-1">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="px-3 py-2 rounded-md text-sm font-medium text-foreground hover:text-primary transition-colors duration-200"
              >
                {link.label}
              </Link>
            ))}
            {/* Updated Join Now button */}
            <Link
              href="/#contact"
              className="ml-4 px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all duration-200 font-medium hover:shadow-lg transform hover:scale-105"
            >
              Join Now
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-foreground hover:text-primary transition-colors"
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {isOpen && (
          <div className="md:hidden pb-4 space-y-2 animate-in slide-in-from-top-2 duration-300">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className="block px-4 py-3 rounded-md text-base font-medium text-foreground hover:text-primary hover:bg-muted transition-colors"
              >
                {link.label}
              </Link>
            ))}
            {/* Updated Join Now button for mobile */}
            <Link
              href="/#contact"
              onClick={() => setIsOpen(false)}
              className="w-full mt-3 px-4 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-colors font-medium block text-center"
            >
              Join Now
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}
