'use client'

import { Star } from 'lucide-react'

export function TrainersSection() {
  const trainers = [
    {
      name: 'Abolade Kamaldeen Bossman',
      role: 'Fitness Coach',
      description: 'Specializes in personalized fitness programs and endurance training',
      image: '/bossman.jpeg',
      initials: 'AK',
    },
    {
      name: 'Rabi Safiyanu',
      role: 'Aerobics Instructor',
      description: 'Expert in group fitness classes and high-energy aerobics sessions',
      image: '/rabi.jpeg',
      initials: 'FU',
    },
    {
      name: 'Rabiu Ibrahim',
      role: '5-Aside Manager',
      description: 'Certified expert in scheduling, conditioning and human relations',
      image: '/male-strength-training-coach.jpg',
      initials: 'RI',
    },
    {
      name: 'Ibrahim Muazzam Yahaya',
      role: 'Wellness & Yoga Coach',
      description: 'Certified yoga instructor and wellness consultant',
      image: '/mxm12.jpg',
      initials: 'UH',
    },
  ]

  return (
    <section id="trainers" className="w-full py-16 sm:py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-20">
          <p className="text-primary font-semibold text-xs sm:text-sm uppercase tracking-wider mb-2">OUR TEAM</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">Professional Trainers</h2>
          <p className="text-gray-600 text-base sm:text-lg mt-4">Meet our certified and experienced fitness professionals</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 sm:gap-6 lg:gap-8">
          {trainers.map((trainer, index) => (
            <div key={index} className="group">
              <div className="bg-white rounded-2xl sm:rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:scale-105 transform">
                <div className="relative h-64 sm:h-72 lg:h-80 overflow-hidden bg-gradient-to-br from-primary/10 to-blue-50 flex items-center justify-center">
                  <img
                    src={trainer.image || "/placeholder.svg"}
                    alt={trainer.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                </div>

                <div className="p-5 sm:p-6 lg:p-8">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-base sm:text-lg lg:text-xl font-bold text-gray-900">{trainer.name}</h3>
                      <p className="text-primary font-semibold text-xs sm:text-sm">{trainer.role}</p>
                    </div>
                    <Star className="w-4 h-4 sm:w-5 sm:h-5 text-primary/40 group-hover:text-primary transition-colors flex-shrink-0" />
                  </div>
                  <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">{trainer.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
