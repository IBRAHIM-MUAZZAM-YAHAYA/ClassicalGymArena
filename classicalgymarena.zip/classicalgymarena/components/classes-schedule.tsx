'use client'

import { Activity, Zap, Heart, Flame, Leaf, User, Clock } from 'lucide-react'

export function ClassesSchedule() {
  const classes = [
    {
      name: 'Aerobics',
      description: 'High-energy cardio fitness classes',
      time: 'Mon & Wed - 6:00 PM',
      icon: Flame,
    },
    {
      name: 'Strength Training',
      description: 'Build muscle with professional coaches',
      time: 'Daily - 5:00 PM - 7:00 PM',
      icon: Activity,
    },
    {
      name: 'Cardio Sessions',
      description: 'Improve endurance and heart health',
      time: 'Tue & Thu - 6:00 PM',
      icon: Heart,
    },
    {
      name: 'HIIT Sessions',
      description: 'High-intensity interval training',
      time: 'Mon & Fri - 5:30 PM',
      icon: Zap,
    },
    {
      name: 'Yoga',
      description: 'Flexibility and mindfulness training',
      time: 'Wed & Sat - 7:00 AM',
      icon: Leaf,
    },
    {
      name: 'Personal Training',
      description: 'One-on-one customized fitness sessions',
      time: 'By Appointment',
      icon: User,
    },
  ]

  return (
    <section id="classes" className="w-full py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-20">
          <p className="text-primary font-semibold text-xs sm:text-sm uppercase tracking-wider mb-2">CLASSES & SCHEDULE</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">Our Fitness Programs</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-8">
          {classes.map((fitnessClass, index) => {
            const IconComponent = fitnessClass.icon
            return (
              <div
                key={index}
                className="bg-gradient-to-br from-white to-gray-50 border border-gray-200 rounded-2xl p-5 sm:p-8 hover:shadow-xl hover:border-primary/30 transition-all duration-300 group cursor-pointer hover:scale-105 transform"
              >
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                  <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 text-primary" />
                </div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-2">{fitnessClass.name}</h3>
                <p className="text-gray-600 text-xs sm:text-sm mb-4">{fitnessClass.description}</p>
                <div className="flex items-center gap-2 text-primary font-semibold text-xs sm:text-sm">
                  <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                  {fitnessClass.time}
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
