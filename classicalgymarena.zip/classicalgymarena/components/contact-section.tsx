export function ContactSection() {
  return (
    <section id="contact" className="w-full py-16 sm:py-20 bg-gradient-to-br from-primary/5 to-blue-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-16">
          <p className="text-primary font-semibold text-xs sm:text-sm uppercase tracking-wider mb-2">GET IN TOUCH</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">Contact Us</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 sm:gap-6 lg:gap-8 mb-8">
          {/* Address */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-2">Address</h3>
            <p className="text-gray-600 text-sm">
              NO C16, Government House Road<br />
              Dutse, Jigawa State, Nigeria
            </p>
          </div>

          {/* Phone */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
              </svg>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-2">Phone</h3>
            <p className="text-gray-600 text-sm">
              +234-8066880296<br />
              +234-8142808110
            </p>
          </div>

          {/* Hours */}
          <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-lg hover:shadow-xl transition-shadow">
            <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
              <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-2">Hours</h3>
            <p className="text-gray-600 text-sm">
              Mon - Fri: 7:00 AM - 12:00 AM<br />
              Sat - Sun: 7:00 AM - 10:00 PM
            </p>
          </div>
        </div>

        {/* Email */}
        <div className="text-center">
          <p className="text-gray-600 mb-2 text-sm sm:text-base">Email us at:</p>
          <a href="mailto:classicalgymarena@gmail.com" className="text-primary text-base sm:text-lg font-semibold hover:underline">
            classicalgymarena@gmail.com
          </a>
        </div>
      </div>
    </section>
  )
}
