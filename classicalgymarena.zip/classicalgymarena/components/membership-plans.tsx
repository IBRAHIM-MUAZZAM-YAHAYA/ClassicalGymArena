'use client'

import { Check } from 'lucide-react'

export function MembershipPlans() {
  const plans = [
    {
      name: 'Regular',
      description: 'Perfect for beginners and occasional visitors',
      features: [
        'Access to gym equipment',
        'Free orientation session',
        'Locker facilities',
        'Water dispenser access',
      ],
      pricing: [
        { duration: 'Daily', price: '₦3,000' },
        { duration: 'Weekly', price: '₦10,000' },
        { duration: '2 Weeks', price: '₦20,000' },
        { duration: 'Monthly', price: '₦30,000' },
        { duration: '3Months', price: '₦75,000' },
        { duration: '6Months', price: '₦120,000' },
        
        
        
      ],
      highlight: false,
    },
    {
      name: 'VIP',
      description: 'Premium experience with exclusive benefits',
      features: [
        'Everything in Regular',
        'Weekly fitness coaching',
        'Access to all group classes',
        'Massage chairs',
        'Table tennis access',
        'Snooker access',
        'Personal trainer consultation',
      ],
      pricing: [
        { duration: 'Daily', price: '₦5,000' },
        { duration: 'Weekly', price: '₦15,000' },
        { duration: '2 Weeks', price: '₦30,000' },
        { duration: 'Monthly', price: '₦50,000' },
        { duration: '3Monthly', price: '₦125,000' },
        { duration: '6Monthly', price: '₦250,000' },

        
        
        
      ],
      highlight: true,
    },
    {
      name: '5-ASIDE Sports',
      description: 'Sports-focused membership',
      features: [
        'Exclusive 5-aside booking',
        'Premium pitch quality',
        'Flexible scheduling',
        'Group coaching available',
      ],
      pricing: [
        { duration: 'Per Hour', price: '₦15,000' },
      ],
      highlight: false,
    },
  ]

  return (
    <section id="membership" className="w-full py-16 sm:py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-20">
          <p className="text-primary font-semibold text-xs sm:text-sm uppercase tracking-wider mb-2">PRICING</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">Membership Plans</h2>
          <p className="text-gray-600 text-base sm:text-lg mt-4">Choose the perfect plan for your fitness journey</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-2xl sm:rounded-3xl overflow-hidden transition-all duration-300 transform ${
                plan.highlight
                  ? 'bg-gradient-to-br from-primary to-primary/80 shadow-2xl ring-2 ring-primary md:scale-105 md:-translate-y-4'
                  : 'bg-white shadow-lg hover:shadow-xl'
              } hover:shadow-xl`}
            >
              {plan.highlight && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-white text-primary px-6 py-1.5 rounded-full text-xs sm:text-sm font-bold shadow-lg">
                  Most Popular
                </div>
              )}

              <div className="p-6 sm:p-8 lg:p-10">
                <h3 className={`text-xl sm:text-2xl font-bold mb-2 ${plan.highlight ? 'text-white' : 'text-gray-900'}`}>
                  {plan.name}
                </h3>
                <p className={`text-xs sm:text-sm mb-6 sm:mb-8 ${plan.highlight ? 'text-blue-100' : 'text-gray-600'}`}>
                  {plan.description}
                </p>

                <div className="mb-6 sm:mb-10 space-y-2 pb-6 sm:pb-8 border-b border-opacity-20 border-white">
                  {plan.pricing.map((price, idx) => (
                    <div key={idx} className={`text-xs sm:text-sm ${plan.highlight ? 'text-blue-100' : 'text-gray-600'}`}>
                      <span className="font-medium">{price.duration}:</span> <span className={`font-bold text-base sm:text-lg ${plan.highlight ? 'text-white' : 'text-primary'}`}>{price.price}</span>
                    </div>
                  ))}
                </div>

                <ul className="space-y-3 sm:space-y-4 mb-6 sm:mb-10">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check className={`w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0 mt-0.5 ${plan.highlight ? 'text-blue-200' : 'text-primary'}`} />
                      <span className={`text-xs sm:text-sm ${plan.highlight ? 'text-blue-50' : 'text-gray-700'}`}>{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-2.5 sm:py-3 rounded-xl font-semibold transition-all duration-300 hover:shadow-lg text-sm sm:text-base ${
                  plan.highlight
                    ? 'bg-white text-primary hover:bg-gray-50'
                    : 'bg-primary text-white hover:bg-primary/90'
                }`}>
                  Choose Plan
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
