'use client'

import { MessageCircle } from 'lucide-react'

export function FloatingWhatsApp() {
  return (
    <a
      href="https://wa.me/2348142808110"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-4 right-4 sm:bottom-8 sm:right-8 z-40 w-14 h-14 sm:w-16 sm:h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center shadow-xl hover:shadow-2xl hover:scale-110 transition-all duration-300 group animate-pulse hover:animate-none"
      title="Chat with us on WhatsApp"
    >
      <div className="absolute inset-0 rounded-full bg-green-400 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-300 animate-pulse"></div>
      <MessageCircle className="w-6 h-6 sm:w-8 sm:h-8 text-white relative z-10" />
    </a>
  )
}
