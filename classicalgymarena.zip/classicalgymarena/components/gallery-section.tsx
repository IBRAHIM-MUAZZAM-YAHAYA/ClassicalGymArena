'use client'

import { Eye } from 'lucide-react'

export function GallerySection() {
  const galleryImages = [
    { id: 1, src: '/gym-images/GYM1.webp', alt: 'Gym floor with equipment and machines' },
    { id: 2, src: '/gym-images/GYM2.webp', alt: 'Spacious gym with treadmills and strength training' },
    { id: 3, src: '/gym-images/GYM3.webp', alt: 'Member using treadmill with fitness display' },
    { id: 4, src: '/gym-images/GYM4.webp', alt: 'Recovery area with massage chairs' },
    { id: 5, src: '/gym-images/GYM5.webp', alt: 'Cardio equipment room with bikes and machines' },
    { id: 6, src: '/gym-images/GYM8.webp', alt: 'Free weight area with barbell and bench' },
    { id: 7, src: '/gym-images/GYM9.webp', alt: 'Strength training equipment area' },
  ]

  return (
    <section id="gallery" className="w-full py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-20">
          <p className="text-primary font-semibold text-xs sm:text-sm uppercase tracking-wider mb-2">GALLERY</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">Our Facilities</h2>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 auto-rows-max">
          {galleryImages.map((image, index) => (
            <div
              key={image.id}
              className={`relative rounded-lg sm:rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group cursor-pointer hover:scale-105 transform ${
                index % 3 === 1 ? 'md:row-span-2' : ''
              } ${index % 4 === 0 ? 'lg:row-span-2' : ''}`}
            >
              <div className={`relative overflow-hidden ${index % 3 === 1 ? 'h-72 sm:h-96' : index % 4 === 0 ? 'h-72 sm:h-96' : 'h-40 sm:h-64'}`}>
                <img
                  src={image.src || "/placeholder.svg"}
                  alt={image.alt}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
                  <Eye className="w-6 h-6 sm:w-8 sm:h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
