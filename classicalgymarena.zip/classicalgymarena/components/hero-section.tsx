'use client'

import { ChevronRight } from 'lucide-react'

export function HeroSection() {
  return (
    <section id="home" className="relative w-full min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-white via-white to-blue-50 pt-20 sm:pt-0">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-blue-100 rounded-full mix-blend-multiply filter blur-3xl opacity-30"></div>
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-primary/30 rounded-full mix-blend-multiply filter blur-3xl opacity-25"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-20 grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 items-center w-full">
        <div className="flex flex-col justify-center space-y-6 sm:space-y-8 text-center lg:text-left">
          <div className="space-y-3 sm:space-y-4">
            <p className="text-primary font-semibold text-base sm:text-lg mb-2 animate-fade-in">WELCOME TO</p>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight animate-slide-up">
              Classical Gym <span className="text-primary">Arena</span>
            </h1>
          </div>
          <p className="text-lg sm:text-xl text-gray-600 leading-relaxed animate-slide-up" style={{ animationDelay: '0.1s' }}>
            We care about Health, your well-being is our concern.
          </p>
          <p className="text-sm sm:text-base text-gray-500 leading-relaxed animate-slide-up" style={{ animationDelay: '0.2s' }}>
            Experience world-class fitness facilities with professional trainers, modern equipment, and a supportive community dedicated to your health journey.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 pt-4 animate-slide-up lg:justify-start justify-center" style={{ animationDelay: '0.3s' }}>
            <button className="px-6 sm:px-8 py-3 sm:py-4 bg-primary text-white rounded-xl hover:bg-primary/90 transition-all duration-300 transform hover:scale-105 font-semibold text-base sm:text-lg shadow-lg hover:shadow-xl flex items-center justify-center gap-2 group">
              Join Now
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-6 sm:px-8 py-3 sm:py-4 border-2 border-primary text-primary rounded-xl hover:bg-primary/5 transition-all duration-300 font-semibold text-base sm:text-lg hover:shadow-lg">
              View Classes
            </button>
          </div>
        </div>

        <div className="relative h-64 sm:h-80 lg:h-full min-h-80 lg:min-h-96 animate-slide-up" style={{ animationDelay: '0.4s' }}>
          <img
            src="/modern-fitness-gym-equipment-professional-training.jpg"
            alt="Classical Gym Arena"
            className="w-full h-full object-cover rounded-2xl sm:rounded-3xl shadow-2xl"
          />
          <div className="absolute inset-0 rounded-2xl sm:rounded-3xl bg-gradient-to-t from-black/20 to-transparent"></div>
        </div>
      </div>
    </section>
  )
}
