'use client'

import { Dumbbell, Heart, Zap } from 'lucide-react'

export function AboutSection() {
  return (
    <section id="about" className="w-full py-16 sm:py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 sm:mb-20">
          <p className="text-primary font-semibold text-xs sm:text-sm uppercase tracking-wider mb-2">ABOUT US</p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900">Our Commitment to Your Health</h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-12 lg:gap-16 items-center">
          <div className="relative h-64 sm:h-80 lg:h-96 overflow-hidden rounded-2xl sm:rounded-3xl shadow-xl order-2 lg:order-1">
            <img
              src="/gym-members-training-strength-equipment.jpg"
              alt="About Classical Gym Arena"
              className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
            />
          </div>

          <div className="space-y-6 sm:space-y-8 order-1 lg:order-2">
            <p className="text-base sm:text-lg text-gray-600 leading-relaxed">
              Classical Gym Arena is a premier fitness center dedicated to transforming lives through professional health and wellness services. With state-of-the-art equipment and experienced trainers, we provide comprehensive fitness solutions.
            </p>

            <div className="space-y-4 sm:space-y-6">
              <div className="flex gap-4 p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-primary/5 to-blue-50 hover:shadow-lg transition-all duration-300 group">
                <div className="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Dumbbell className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900">Strength Training</h3>
                  <p className="text-gray-600 text-xs sm:text-sm">Professional equipment and expert guidance for building strength.</p>
                </div>
              </div>

              <div className="flex gap-4 p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-primary/5 to-blue-50 hover:shadow-lg transition-all duration-300 group">
                <div className="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900">Cardio & Aerobics</h3>
                  <p className="text-gray-600 text-xs sm:text-sm">Modern cardio machines and group aerobics classes.</p>
                </div>
              </div>

              <div className="flex gap-4 p-4 sm:p-6 rounded-2xl bg-gradient-to-br from-primary/5 to-blue-50 hover:shadow-lg transition-all duration-300 group">
                <div className="flex-shrink-0 w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <Heart className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900">Wellness Services</h3>
                  <p className="text-gray-600 text-xs sm:text-sm">Comprehensive wellness and recovery programs.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
