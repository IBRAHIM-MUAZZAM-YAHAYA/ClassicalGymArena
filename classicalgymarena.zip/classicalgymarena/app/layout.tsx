import type { Metadata } from 'next'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Classical Gym Arena - Professional Fitness Center',
  description:
    'We care about Health, your well-being is our concern. Classical Gym Arena offers professional fitness training, group classes, and wellness programs.',
  generator: 'v0.app',
  icons: {
    icon: [
      {
        url: '/gym-images/gymlogo.JPG', // light mode icon
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/gym-images/gymlogo-dark.JPG', // dark mode icon
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/gym-images/gymlogo.JPG', // fallback
        type: 'image/svg+xml',
      },
    ],
    apple: '/gym-images/gymlogo.JPG', // Apple touch icon
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        {children}
        <Analytics />
      </body>
    </html>
  )
}
