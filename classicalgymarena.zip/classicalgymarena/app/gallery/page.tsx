'use client'

import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { FloatingWhatsApp } from '@/components/floating-whatsapp'
import { Eye } from 'lucide-react'

export default function GalleryPage() {
  const galleryImages = [
    // Indoor Gym Facilities
    { id: 1, src: '/gym-images/GYM1.webp', alt: 'Gym floor with cable machines and equipment', category: 'Indoor' },
    { id: 2, src: '/gym-images/GYM2.webp', alt: 'Spacious gym with treadmills and strength training under yellow lighting', category: 'Indoor' },
    { id: 3, src: '/gym-images/GYM3.webp', alt: 'Member using treadmill with digital fitness displays', category: 'Indoor' },
    { id: 4, src: '/gym-images/GYM4.webp', alt: 'Recovery area with massage chairs and stability balls', category: 'Indoor' },
    { id: 5, src: '/gym-images/GYM5.webp', alt: 'Cardio equipment room with exercise bikes and machines', category: 'Indoor' },
    { id: 6, src: '/gym-images/GYM8.webp', alt: 'Free weight area with barbell, bench, and strength training', category: 'Indoor' },
    { id: 7, src: '/gym-images/GYM9.webp', alt: 'Multi-functional strength training equipment area', category: 'Indoor' },
    // Outdoor Sports Facilities & 5-Aside Court
    { id: 8, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.15.50%20PM-pj0l0ZmzdBi8a3RXZuuozMBn9Kh4C4.jpeg', alt: 'Exterior facility entrance with sports court and pathways', category: 'Outdoor' },
    { id: 9, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.18.51%20PM%20%281%29-SCJIuXQzI3OoU3pc78ndJWGyGvBevw.jpeg', alt: 'Player at 5-aside sports court in blue shirt', category: 'Sports' },
    { id: 10, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.18.55%20PM-KtU4thx5AbWerkuTkg4D291KkE4RUq.jpeg', alt: 'Player in striped blue jersey on field', category: 'Sports' },
    { id: 11, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.18.51%20PM-nkJhAlENTTwrrDdIhdgWZQkYDTY6f9.jpeg', alt: 'Players on field with soccer goals visible', category: 'Sports' },
    { id: 12, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.18.55%20PM%20%281%29-w7UxdatL4PrTGGz3CnDsRWFqb9sd0g.jpeg', alt: 'Player running on 5-aside field near building', category: 'Sports' },
    { id: 13, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.18.55%20PM%20%282%29-KYmfZNZH5ydcLvo0w3sgdHTs1SsNpy.jpeg', alt: 'Two young athletes in different team jerseys on field', category: 'Sports' },
    { id: 14, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.18.50%20PM-mM5CVwa0f76ObeRo8BabHDhU0HGcRk.jpeg', alt: 'Indoor gym with strength training equipment and people working out', category: 'Indoor' },
    { id: 15, src: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/WhatsApp%20Image%202025-11-16%20at%207.15.51%20PM-BGoFpQK5MK7iovtVnZIC2i7gBmuexC.jpeg', alt: 'Exterior building and sports court with nets', category: 'Outdoor' },
    { id: 16, src: '/gym-images/gym10.JPG', alt: 'Exterior building ', category: 'Outdoor' },
  ]

  return (
    <main className="w-full">
      <Navbar />
      
      {/* Gallery Header */}
      <section className="w-full py-12 sm:py-20 bg-gradient-to-br from-white to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-primary font-semibold text-xs sm:text-sm uppercase tracking-widest mb-3">EXPLORE OUR FACILITIES</p>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 text-balance">
              Classical Gym Arena Gallery
            </h1>
            <p className="text-gray-600 text-base sm:text-lg max-w-2xl mx-auto text-pretty">
              Discover our state-of-the-art indoor gym facilities, outdoor 5-aside sports courts, and professional training environment
            </p>
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="w-full py-16 sm:py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {galleryImages.map((image, index) => (
              <div
                key={image.id}
                className={`group relative rounded-xl sm:rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-300 cursor-pointer ${
                  index % 5 === 0 || index % 5 === 4 ? 'sm:col-span-2 lg:col-span-1' : ''
                } hover:scale-105 transform`}
              >
                <div className="relative h-56 sm:h-64 lg:h-72 overflow-hidden bg-gray-100">
                  <img
                    src={image.src || "/placeholder.svg"}
                    alt={image.alt}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  
                  {/* Overlay */}
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors duration-300 flex flex-col items-center justify-center">
                    <Eye className="w-8 h-8 sm:w-10 sm:h-10 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300 mb-2" />
                    <span className="text-white text-xs sm:text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      {image.category}
                    </span>
                  </div>
                </div>
                
                {/* Image Description */}
                <div className="p-3 sm:p-4 bg-white">
                  <p className="text-xs sm:text-sm text-gray-600 line-clamp-2">{image.alt}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 sm:py-16 bg-gradient-to-r from-primary/10 via-transparent to-primary/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
            Ready to Experience Our Facilities?
          </h2>
          <p className="text-gray-600 text-base sm:text-lg mb-8">
            Join Classical Gym Arena today and get access to our world-class equipment and sports facilities.
          </p>
          <button className="px-8 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-all duration-300 font-semibold shadow-lg hover:shadow-xl transform hover:scale-105">
            Join Now
          </button>
        </div>
      </section>

      <Footer />
      <FloatingWhatsApp />
    </main>
  )
}
